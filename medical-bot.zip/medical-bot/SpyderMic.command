#!/bin/bash
cd ~/Desktop/medical-bot
source /opt/anaconda3/bin/activate base
python run_fullbot.py
echo ""
echo "Bot stopped. Press any key to close."
read