from slm import MedicalSLM
from tts_module import OfflineTTS
from stt_module import run_stt

if __name__ == "__main__":
    print("="*60)
    print("  RUNNING: FULL SYSTEM (STT + SLM + TTS)")
    print("="*60)
    
    print("Loading Language Model...")
    slm = MedicalSLM()
    
    print("Loading Voice Module...")
    tts = OfflineTTS()
    
    run_stt(slm_instance=slm, tts_instance=tts)




