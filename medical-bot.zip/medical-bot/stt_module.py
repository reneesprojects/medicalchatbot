import sounddevice as sd
import numpy as np
from transformers import pipeline
import collections
import threading
import time
import torch
import queue
from collections import deque
import librosa
import re
import os

# Global references for our plugins
slm_plugin = None
tts_plugin = None

bot_is_speaking = threading.Event()
bot_interrupt_requested = threading.Event()
ignore_input_until = 0.0

# Configuration
whisper_rate = 16000
audio_buffer = 10
asr_queue_max_items = 3
vad_window_seconds = 0.032
silence_duration_before_transcribe_s = 1.2
speech_prob_threshold = 0.5
model_name = os.environ.get("WHISPER_MODEL_NAME", "openai/whisper-small")
mic_device_id_config = None

# How long after TTS finishes to ignore mic input
post_tts_ignore_seconds = 1.0
interrupt_grace_seconds = 0.8

# Interrupt detection
interrupt_speech_prob_threshold = 0.95
interrupt_min_speech_seconds = 1.2

min_transcript_chars = 2
min_audio_duration_seconds = 0.3
min_audio_rms = 0.003
duplicate_transcript_window_seconds = 0.5


# Performance Tracker
class PerformanceTracker:
    def __init__(self):
        self.latencies = deque(maxlen=100)
        self.audio_durations = deque(maxlen=100)
        self.transcription_count = 0
        self.successful_count = 0
        self.filtered_count = 0
        self.empty_count = 0
        self.start_time = time.time()

    def add_transcription(self, latency, audio_duration):
        self.latencies.append(latency)
        self.audio_durations.append(audio_duration)
        self.transcription_count += 1
        self.successful_count += 1

    def add_filtered(self):
        self.transcription_count += 1
        self.filtered_count += 1

    def add_empty(self):
        self.transcription_count += 1
        self.empty_count += 1

    def print_stats(self):
        if not self.latencies:
            return
        under_5 = sum(1 for l in self.latencies if l < 5.0)
        total = len(self.latencies)
        print("="*60)
        print("SESSION STATISTICS")
        print("="*60)
        print(f"Total transcriptions: {self.transcription_count}")
        print(f"Successful: {self.successful_count}")
        print(f"Filtered: {self.filtered_count}")
        print(f"Empty: {self.empty_count}")
        print(f"\nLatency Analysis:")
        print(f"Average: {np.mean(self.latencies):.2f}s")
        print(f"Min/Max: {np.min(self.latencies):.2f}s / {np.max(self.latencies):.2f}s")
        print(f"Under 5s: {under_5}/{total} ({100*under_5/total:.1f}%)")
        print(f"\nSession duration: {(time.time() - self.start_time)/60:.1f} minutes")
        print("="*60 + "\n")


tracker = PerformanceTracker()

# Initialize Models
try:
    vad_model, _ = torch.hub.load(
        repo_or_dir='snakers4/silero-vad',
        model='silero_vad',
        force_reload=False,
        onnx=False,
        trust_repo=True
    )
    vad_model = vad_model.to(torch.device('cuda' if torch.cuda.is_available() else 'cpu'))
except Exception as e:
    print(f"VAD model failed to load: {e}")
    vad_model = None

os.environ["TRANSFORMERS_CACHE"] = os.path.expanduser("~/.cache/huggingface")

try:
    asr_pipe = pipeline(
        "automatic-speech-recognition",
        model=model_name,
        device=0 if torch.cuda.is_available() else -1,
        model_kwargs={"local_files_only": True}
    )
except Exception:
    asr_pipe = pipeline(
        "automatic-speech-recognition",
        model=model_name,
        device=-1
    )

# Buffers
buffer_lock = threading.Lock()
stop_event = threading.Event()
vad_process_buffer = collections.deque()
speech_audio_buffer = collections.deque()
asr_queue = queue.Queue(maxsize=asr_queue_max_items)

# Global state
actual_device_sample_rate = whisper_rate
silence_start_time = None
speaking_state = False
recording_notified = False
last_handled_transcript = ""
last_handled_transcript_time = 0.0
bot_speaking_since = 0.0
interrupt_speech_seconds = 0.0


def _normalize_transcript(text):
    text = (text or "").lower()
    text = re.sub(r"[^a-z0-9\s']", " ", text)
    return re.sub(r"\s+", " ", text).strip()

def _should_ignore_transcript(text):
    global last_handled_transcript, last_handled_transcript_time

    normalized = _normalize_transcript(text)
    if len(normalized) < min_transcript_chars:
        return True, "too short"

    # Filter Whisper hallucinations of prompt template artifacts
    hallucinations = ["user", "assistant", "system", "end"]
    if normalized.strip() in hallucinations:
        return True, "hallucination"

    now = time.time()
    is_duplicate = normalized == last_handled_transcript
    is_recent = now - last_handled_transcript_time < duplicate_transcript_window_seconds
    if is_duplicate and is_recent:
        return True, "duplicate transcript"

    last_handled_transcript = normalized
    last_handled_transcript_time = now
    return False, ""


def _normalize_audio_for_asr(audio_segment):
    audio_segment = audio_segment.astype(np.float32)
    rms = float(np.sqrt(np.mean(np.square(audio_segment)))) if audio_segment.size else 0.0
    if rms < min_audio_rms:
        return None, rms
    peak = float(np.max(np.abs(audio_segment)))
    if peak > 0:
        audio_segment = audio_segment / peak
    return audio_segment, rms


def _extract_reply_payload(result):
    if result is None:
        return {'response': "", 'latency': 0.0, 'tokens': 0}
    if not isinstance(result, dict):
        return {'response': str(result), 'latency': 0.0, 'tokens': 0}

    payload = (
        result.get('payload')
        or result.get('response')
        or result.get('data')
        or result.get('text')
        or result.get('message')
        or ""
    )

    if isinstance(payload, dict):
        payload = (
            payload.get('response')
            or payload.get('text')
            or payload.get('message')
            or payload.get('content')
            or payload.get('data')
            or ""
        )

    return {
        'response': str(payload).strip(),
        'latency': float(result.get('latency') or 0.0),
        'tokens': int(result.get('tokens') or 0)
    }


def _is_bot_active():
    return bot_is_speaking.is_set() or time.time() < ignore_input_until


def _can_accept_mic_input():
    return not bot_is_speaking.is_set() and time.time() >= ignore_input_until


def _request_bot_interrupt():
    if bot_interrupt_requested.is_set():
        return
    bot_interrupt_requested.set()
    print("\n[interrupt detected] Stopping bot speech...\n")


def _queue_audio_for_asr(audio):
    try:
        asr_queue.put_nowait(audio)
        return
    except queue.Full:
        pass
    try:
        asr_queue.get_nowait()
        asr_queue.task_done()
        print("[dropped stale audio segment]")
    except queue.Empty:
        pass
    try:
        asr_queue.put_nowait(audio)
    except queue.Full:
        print("[dropped new audio segment: ASR busy]")


def clear_all_buffers():
    global silence_start_time, speaking_state, recording_notified, interrupt_speech_seconds

    with buffer_lock:
        vad_process_buffer.clear()
        speech_audio_buffer.clear()

    drained = 0
    while not asr_queue.empty():
        try:
            asr_queue.get_nowait()
            asr_queue.task_done()
            drained += 1
        except queue.Empty:
            break

    if drained > 0:
        print(f"[flushed {drained} queued audio segment(s)]")

    silence_start_time = None
    speaking_state = False
    recording_notified = False
    interrupt_speech_seconds = 0.0


def audio_callback(indata, frames, time_obj, status):
    if indata.shape[0] == 0:
        return
    if not _can_accept_mic_input():
        return
    with buffer_lock:
        vad_process_buffer.extend(indata[:, 0])


def vad_producer():
    global actual_device_sample_rate, silence_start_time, speaking_state, recording_notified
    global interrupt_speech_seconds

    vad_model_sample_rate = whisper_rate
    VAD_TARGET_SAMPLES_16KHZ = 512

    while not stop_event.is_set():
        if vad_model is None:
            time.sleep(0.1)
            continue

        if not _can_accept_mic_input():
            with buffer_lock:
                vad_process_buffer.clear()
                speech_audio_buffer.clear()
            time.sleep(0.05)
            continue

        processed_vad_any = False
        vad_window_size_samples = max(1, int(actual_device_sample_rate * vad_window_seconds))

        chunks_to_process = []
        with buffer_lock:
            while len(vad_process_buffer) >= vad_window_size_samples:
                chunk = np.array(list(vad_process_buffer)[:vad_window_size_samples])
                for _ in range(vad_window_size_samples):
                    vad_process_buffer.popleft()
                chunks_to_process.append(chunk)

        for vad_chunk in chunks_to_process:
            if actual_device_sample_rate != vad_model_sample_rate:
                vad_chunk_resampled = librosa.resample(
                    vad_chunk.astype(np.float32),
                    orig_sr=actual_device_sample_rate,
                    target_sr=vad_model_sample_rate
                )
                if len(vad_chunk_resampled) > VAD_TARGET_SAMPLES_16KHZ:
                    vad_chunk_resampled = vad_chunk_resampled[:VAD_TARGET_SAMPLES_16KHZ]
                elif len(vad_chunk_resampled) < VAD_TARGET_SAMPLES_16KHZ:
                    vad_chunk_resampled = np.pad(
                        vad_chunk_resampled,
                        (0, VAD_TARGET_SAMPLES_16KHZ - len(vad_chunk_resampled))
                    )
                audio_tensor = torch.from_numpy(vad_chunk_resampled)
            else:
                vad_chunk_f32 = vad_chunk.astype(np.float32)
                if len(vad_chunk_f32) > VAD_TARGET_SAMPLES_16KHZ:
                    vad_chunk_f32 = vad_chunk_f32[:VAD_TARGET_SAMPLES_16KHZ]
                elif len(vad_chunk_f32) < VAD_TARGET_SAMPLES_16KHZ:
                    vad_chunk_f32 = np.pad(
                        vad_chunk_f32,
                        (0, VAD_TARGET_SAMPLES_16KHZ - len(vad_chunk_f32))
                    )
                audio_tensor = torch.from_numpy(vad_chunk_f32)

            speech_prob = vad_model(audio_tensor, vad_model_sample_rate).item()
            processed_vad_any = True

            if bot_is_speaking.is_set():
                with buffer_lock:
                    speech_audio_buffer.clear()
                speaking_state = False
                silence_start_time = None
                recording_notified = False

                can_interrupt = (time.time() - bot_speaking_since) >= interrupt_grace_seconds
                if can_interrupt and speech_prob > interrupt_speech_prob_threshold:
                    interrupt_speech_seconds += vad_window_seconds
                else:
                    interrupt_speech_seconds = 0.0

                if interrupt_speech_seconds >= interrupt_min_speech_seconds:
                    _request_bot_interrupt()
                continue

            if speech_prob > speech_prob_threshold:
                if not speaking_state:
                    if not recording_notified:
                        print("Recording...", end="", flush=True)
                        recording_notified = True
                    speaking_state = True
                    silence_start_time = None
                with buffer_lock:
                    speech_audio_buffer.extend(vad_chunk)
            else:
                if speaking_state:
                    if silence_start_time is None:
                        silence_start_time = time.time()

                    if (time.time() - silence_start_time) >= silence_duration_before_transcribe_s:
                        speaking_state = False
                        silence_start_time = None
                        recording_notified = False

                        with buffer_lock:
                            if len(speech_audio_buffer) > 0:
                                full_audio = np.array(list(speech_audio_buffer)).astype(np.float32)
                                speech_audio_buffer.clear()
                            else:
                                full_audio = None

                        if full_audio is not None:
                            if actual_device_sample_rate != whisper_rate:
                                full_audio = librosa.resample(
                                    full_audio,
                                    orig_sr=actual_device_sample_rate,
                                    target_sr=whisper_rate
                                )
                            if not _is_bot_active():
                                _queue_audio_for_asr(full_audio)
                    else:
                        with buffer_lock:
                            speech_audio_buffer.extend(vad_chunk)
                else:
                    silence_start_time = None

        with buffer_lock:
            buf_len = len(speech_audio_buffer)

        if buf_len >= int(actual_device_sample_rate * audio_buffer):
            with buffer_lock:
                if len(speech_audio_buffer) > 0:
                    full_audio = np.array(list(speech_audio_buffer)).astype(np.float32)
                    speech_audio_buffer.clear()
                else:
                    full_audio = None

            if full_audio is not None and not _is_bot_active():
                if actual_device_sample_rate != whisper_rate:
                    full_audio = librosa.resample(
                        full_audio,
                        orig_sr=actual_device_sample_rate,
                        target_sr=whisper_rate
                    )
                _queue_audio_for_asr(full_audio)

            speaking_state = False
            recording_notified = False

        if not processed_vad_any:
            time.sleep(0.01)


def asr_consumer():
    global ignore_input_until, bot_speaking_since

    while not stop_event.is_set() or not asr_queue.empty():
        try:
            audio_segment = asr_queue.get(timeout=0.1)
        except queue.Empty:
            time.sleep(0.05)
            continue

        # task_done() is called exactly once per get() in the finally below
        try:
            if _is_bot_active():
                continue

            if audio_segment.size == 0:
                tracker.add_empty()
                continue

            audio_duration = audio_segment.shape[0] / whisper_rate
            if audio_duration < min_audio_duration_seconds:
                tracker.add_empty()
                continue

            audio_segment, audio_rms = _normalize_audio_for_asr(audio_segment)
            if audio_segment is None:
                print(f"\n[ignored audio: too quiet, rms={audio_rms:.4f}]")
                tracker.add_empty()
                continue

            print("\r" + " " * 40 + "\r", end="", flush=True)

            start_time_asr = time.time()
            result = asr_pipe(
                {"raw": audio_segment, "sampling_rate": whisper_rate},
                generate_kwargs={"language": "english", "task": "transcribe"}
            )
            latency = time.time() - start_time_asr
            transcribed_text = result["text"].strip()

            if not transcribed_text:
                tracker.add_empty()
                continue

            should_ignore, ignore_reason = _should_ignore_transcript(transcribed_text)
            if should_ignore:
                print(f"\n[ignored: {ignore_reason}] {transcribed_text}")
                tracker.add_filtered()
                continue

            print("\n" + "━"*60)
            print(f"YOU: {transcribed_text}")
            print("━"*60)

            if slm_plugin is not None:
                print("Thinking...", end="", flush=True)
                try:
                    slm_result = slm_plugin.generate_response(transcribed_text)
                except Exception as e:
                    print(f"\nSLM error: {e}")
                    tracker.add_filtered()
                    continue

                slm_result = _extract_reply_payload(slm_result)
                response_text = (slm_result.get('response') or "").strip()
                if not response_text:
                    response_text = "Sorry, I could not form a clear answer. Please ask again."
                slm_result['latency'] = float(slm_result.get('latency') or 0.0)

                print("\r" + " " * 40 + "\r", end="", flush=True)
                print(f"BOT: {response_text}")
                print("━"*60)

                if tts_plugin is not None:
                    print("Speaking...", end="", flush=True)
                    bot_is_speaking.set()
                    bot_interrupt_requested.clear()
                    bot_speaking_since = time.time()
                    clear_all_buffers()

                    try:
                        tts_plugin.speak(response_text, stop_event=bot_interrupt_requested)
                    except Exception as e:
                        print(f"\nTTS error: {e}")
                    finally:
                        clear_all_buffers()
                        ignore_input_until = time.time() + post_tts_ignore_seconds
                        bot_is_speaking.clear()
                        bot_interrupt_requested.clear()

                    print("\nListening...\n")

                total_latency = latency + slm_result['latency']
                icon = "✓" if total_latency < 5.0 else "⚠"
                print(f"{icon} Total: {total_latency:.2f}s (STT: {latency:.2f}s + SLM: {slm_result['latency']:.2f}s)\n")

            else:
                icon = "✓" if latency < 5.0 else "⚠"
                print(f"{icon} {latency:.2f}s\n")

            tracker.add_transcription(latency, audio_duration)

        except Exception as e:
            print(f"\nError: {e}\n")
            bot_is_speaking.clear()
            bot_interrupt_requested.clear()

        finally:
            asr_queue.task_done()


def run_stt(slm_instance=None, tts_instance=None):
    global slm_plugin, tts_plugin, actual_device_sample_rate
    global last_handled_transcript, last_handled_transcript_time
    global ignore_input_until

    slm_plugin = slm_instance
    tts_plugin = tts_instance
    stop_event.clear()
    bot_is_speaking.clear()
    bot_interrupt_requested.clear()
    last_handled_transcript = ""
    last_handled_transcript_time = 0.0
    ignore_input_until = 0.0

    print("\nAudio Engine Ready!")
    print("Speak naturally. Talk over the bot to interrupt.")
    print("Press Ctrl+C to stop.\n")

    actual_mic_device_id = mic_device_id_config

    if actual_mic_device_id is None:
        input_device_info = sd.query_devices(kind='input')
        actual_device_sample_rate = input_device_info['default_samplerate']
    else:
        try:
            device_info = sd.query_devices(actual_mic_device_id, 'input')
            if device_info['max_input_channels'] == 0:
                raise ValueError(f"Device ID {actual_mic_device_id} has no input channels.")
            actual_device_sample_rate = device_info['default_samplerate']
        except (sd.PortAudioError, ValueError):
            actual_mic_device_id = None
            actual_device_sample_rate = sd.query_devices(kind='input')['default_samplerate']

    vad_producer_thread = threading.Thread(target=vad_producer, daemon=True)
    vad_producer_thread.start()

    asr_consumer_thread = threading.Thread(target=asr_consumer, daemon=True)
    asr_consumer_thread.start()

    try:
        sd_blocksize = int(actual_device_sample_rate * 0.05)
        with sd.InputStream(
            samplerate=actual_device_sample_rate,
            channels=1,
            callback=audio_callback,
            blocksize=sd_blocksize,
            device=actual_mic_device_id
        ):
            while True:
                time.sleep(0.1)

    except KeyboardInterrupt:
        print("\n[STOPPING] Shutting down...")

    finally:
        stop_event.set()
        vad_producer_thread.join(timeout=2)
        asr_consumer_thread.join(timeout=2)
        tracker.print_stats()
        
        
        
        