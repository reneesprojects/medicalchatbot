import pyttsx3
import threading
import time


class OfflineTTS:
    """Text-to-Speech using pyttsx3 - Fully Offline"""

    def __init__(self):
        self.rate = 190
        self._lock = threading.Lock()
        print("TTS module ready.\n")

    def _create_engine(self):
        engine = pyttsx3.init()
        voices = engine.getProperty('voices')
        for voice in voices:
            if 'joelle' in voice.name.lower():
                engine.setProperty('voice', voice.id)
                print(f"TTS using: {voice.name}\n")
                break
        engine.setProperty('rate', self.rate)
        return engine

    def speak(self, text, play_audio=True, stop_event=None):
        if not text or not text.strip():
            return
        if not play_audio:
            return

        with self._lock:
            engine = None
            try:
                engine = self._create_engine()
                engine.say(text)
                engine.runAndWait()
            except Exception as e:
                print(f"TTS error: {e}")
            finally:
                try:
                    if engine is not None:
                        engine.stop()
                except Exception:
                    pass

    def cleanup(self):
        pass
    
    
    
    
    